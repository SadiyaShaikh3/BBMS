<?php
    include('connection.php');
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="css/s1.css">
    <style>
        body {
            background-image: url("image/background.jpg");
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body>
<div id ="full">
        <div id="inner_full">
            <div id="header"><h2><center><a href="admin-home.php" style="text-decoration: none;color: white;">Blood Bank Management System</a></h2></center></div>
            <div id="body">
                <br>
                <?php
                $un=$_SESSION['un'];
                if(!$un)
                {
                    header("Location:index.php");
                }
                ?>
                <h1>Welcome Admin</h1><br><br>
                <ul>
                    <li><br><a href="donor-red.php">Donor Registration</a></li>
                    <li><br><a href="donor-list.php">Donor List</a></li>
                    <li><br><a href="stock-blood.php">Stock Blood List</a></li>
                </ul><br><br><br><br><br>
                <ul>
                    <li><br><a href="out-stock-blood-list.php">Out Stock Blood List</a></li>
                    <li><br><a href="exchange-blood-list.php">Exchange Blood Registration</a></li>
                    <li><br><a href="exchange-blood-list1.php">Exchange Blood list</a></li>
                </ul>
            </div>
            <div id="footer"><h4 align="center">Copyright@myprojecthd</h4>
                <p align="center"><a href="logout.php"><font color="white">Logout</font></a></p>
            </div>
        </div>
</div>
</body>
</html>