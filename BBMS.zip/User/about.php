<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Blood Bank About</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div class="header">
	<div class="logo"><h2><center>Blood Bank Management System</center></h2></div>
	<div class="nav">
		<div id="a"><a href="index.php">Home</a></div>
		<div id="b"><a href="about.php">About Us</a></div>
		<div id="c"><a href="contact.php">Contact Us</a></div>
		<div id="d"><a href="login.php">Login</a></div>
	</div>
</div>
<div class="banner"><h2 align="center" style="color: white"><br><br><br><br><br><br><br><br><br>Blood Bank</h2></div>
<div class="container">
	<br>
	<h2 align="center" style="color:red">About Blood Bank</h2>
	<br>
	<p>A blood bank is a crucial healthcare facility dedicated to collecting, testing, and storing donated blood for medical treatments.</p>
	<p>Donors voluntarily contribute blood, which undergoes meticulous screening for infections and categorization based on type and Rh factor.</p>
	<p>The blood bank maintains a comprehensive database of donor information, enabling efficient inventory management and tracking of expiration dates.</p>
	<p>This database ensures a secure and accessible repository for healthcare providers to source suitable blood units promptly.</p>
	<p>Blood banks play a vital role during emergencies, providing a lifeline for patients in need of transfusions. Their organized systems contribute to the safety and availability of the blood supply.</p>
</div><br><br><br>
<div class="footer"><br><h2 align="center">Copyright@myprojecthd2023-24</h2></div>
</body>
</html>