<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Blood Bank Home</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div class="header">
	<div class="logo"><h2><center>Blood Bank Management System</center></h2></div>
	<div class="nav">
		<div id="a"><a href="index.php">Home</a></div>
		<div id="b"><a href="about.php">About Us</a></div>
		<div id="c"><a href="contact.php">Contact Us</a></div>
		<div id="d"><a href="login.php">Login</a></div>
	</div>
</div>
<div class="banner"><h2 align="center" style="color: white"><br><br><br><br><br><br><br><br><br>Blood Bank</h2></div>
<div class="container">
	<br>
	<h2 align="center" style="color:red">Doctor's Information</h2>
	<center><table border="1px">
		<tr>
			<td width="200px", height="50px" style="color: red"><center><b>Doctor Name</b></center></td>
			<td width="200px", height="50px" style="color: red"><center><b>Mobile No</b></center></td>
			<td width="200px", height="50px" style="color: red"><center><b>Address</b></center></td>
			<td width="200px", height="50px" style="color: red"><center><b>Specialization</b></center></td>
		</tr>
		<tr>
			<td width="200px", height="50px"><center>Dr.Rachana M R</center></td>
			<td width="200px", height="50px"><center>8722382674</center></td>
			<td width="200px", height="50px"><center>BG Nagar</center></td>
			<td width="200px", height="50px"><center>Hematology</center></td>
		</tr>
	</table></center>
</div>
<div class="footer"><br><h2 align="center">Copyright@myprojecthd2023-24</h2></div>
</body>
</html>