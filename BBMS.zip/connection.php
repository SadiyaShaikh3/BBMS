<?php
$db=new PDO('mysql:host=localhost;dbname=mypro_bbms','root','');
?>